### Crear entorno virtual
*En la carpeta del proyecto*
python -m venv venv
venv\Scripts\activate

### Instalar Requerimientos
Ejecutar: pip install -r requirements.txt