﻿Imports System.Data.SqlClient
Imports System.Runtime.InteropServices
Imports System.Windows.Forms.VisualStyles.VisualStyleElement

Public Class Form1
    Dim query As String
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        query = "SELECT * FROM VW_DatosSuperMarket1;"
        DataGridView1.DataSource = Connection.SelectQuery(query)

    End Sub


    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click
        AgregarCliente.Show()

    End Sub

    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click
        Productos.Show()

    End Sub

    Private Sub PictureBox4_Click(sender As Object, e As EventArgs) Handles PictureBox4.Click

    End Sub
End Class
