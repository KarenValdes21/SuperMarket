﻿Imports System.Data.SqlClient
Imports System.Windows.Forms.VisualStyles.VisualStyleElement
Imports NSubstitute.Core

Public Class AgregarCliente
    Dim query As String
    Dim adapter As String
    Dim conexion As String

    Private Sub AgregarCliente_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        query = "select distinct Cliente_Identificador,NombreSegmento,NombreRegion, NombreCiudad, NombreEstado , NombrePais 
                from VW_DatosSuperMarket"
        DataGridView1.DataSource = Connection.SelectQuery(query)

        Connection.LlenarCB("exec LlenarCbCiudad", CbCiudad)
        Connection.LlenarCB("exec LlenarCbEstado", CbEstado)
        Connection.LlenarCB("exec LlenarCbPais", CbPais)


    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If String.IsNullOrWhiteSpace(TxtFiltro.Text) OrElse
  String.IsNullOrWhiteSpace(CbRegion.Text) Then
            MsgBox("Por favor, revise que todos los campos estén llenos")
            Return
        End If

        Dim ClienteID As String = TxtFiltro.Text

        Dim UsuarioCrea As Integer = TxtIdcrea.Text

        Connection.AgregarCliente(ClienteID, UsuarioCrea)
    End Sub

    Private Sub Label7_Click(sender As Object, e As EventArgs) Handles Label7.Click

    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CbPais.SelectedIndexChanged
        DataGridView1.DataSource = Connection.SelectQuery("exec llenarDtCliente '" + ObtenerPais() + "','" + ObtenerEstado() + "','" + ObtenerCiudad() + "','" + ObtenerRegion() + "','" + TxtFiltro.Text + "'")
    End Sub

    Private Sub CbCiudad_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CbCiudad.SelectedIndexChanged
        CbRegion.Items.Clear()
        Connection.LlenarCB("exec LlenarCbRegion " + ObtenerCiudad(), CbRegion)
        DataGridView1.DataSource = Connection.SelectQuery("exec llenarDtCliente '" + ObtenerPais() + "','" + ObtenerEstado() + "','" + ObtenerCiudad() + "','" + ObtenerRegion() + "','" + TxtFiltro.Text + "'")

    End Sub
    Function ObtenerPais() As String
        Dim P As String
        If CbPais.SelectedIndex >= 0 Then
            P = CType(CbPais.Items(CbPais.SelectedIndex), ObtenerId).ItemData
        End If

        Return P
    End Function
    Function ObtenerRegion() As String
        Dim P As String
        If CbRegion.SelectedIndex >= 0 Then
            P = CType(CbRegion.Items(CbRegion.SelectedIndex), ObtenerId).ItemData
        End If
        Return P
    End Function
    Function ObtenerEstado() As String
        Dim P As String
        If CbEstado.SelectedIndex >= 0 Then
            P = CType(CbEstado.Items(CbEstado.SelectedIndex), ObtenerId).ItemData
        End If
        Return P
    End Function
    Function ObtenerCiudad() As String
        Dim P As String
        If CbCiudad.SelectedIndex >= 0 Then
            P = CType(CbCiudad.Items(CbCiudad.SelectedIndex), ObtenerId).ItemData
        End If
        Return P
    End Function

    Private Sub CbEstado_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CbEstado.SelectedIndexChanged
        MsgBox(ObtenerEstado)
        DataGridView1.DataSource = Connection.SelectQuery("exec llenarDtCliente '" + ObtenerPais() + "','" + ObtenerEstado() + "','" + ObtenerCiudad() + "','" + ObtenerRegion() + "','" + TxtFiltro.Text + "'")

    End Sub

    Private Sub CbRegion_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CbRegion.SelectedIndexChanged
        DataGridView1.DataSource = Connection.SelectQuery("exec llenarDtCliente '" + ObtenerPais() + "','" + ObtenerEstado() + "','" + ObtenerCiudad() + "','" + ObtenerRegion() + "','" + TxtFiltro.Text + "'")

    End Sub

    Private Sub TxtFiltro_KeyUp(sender As Object, e As KeyEventArgs) Handles TxtFiltro.KeyUp
        DataGridView1.DataSource = Connection.SelectQuery("exec llenarDtCliente '" + ObtenerPais() + "','" + ObtenerEstado() + "','" + ObtenerCiudad() + "','" + ObtenerRegion() + "','" + TxtFiltro.Text + "'")

    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub PictureBox2_Click(sender As Object, e As EventArgs) Handles PictureBox2.Click
        TxtFiltro.Clear()
        CbCiudad.Items.Clear()
        CbEstado.Items.Clear()
        CbRegion.Items.Clear()
        CbPais.Items.Clear()
        CbSegmento.Items.Clear()
        TxtIdcrea.Clear()


    End Sub
End Class