﻿using System;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;

namespace SuperMarketEditando
{

    public partial class AgregarCliente
    {
        private string query;
        private string adapter;
        private string conexion;

        public AgregarCliente()
        {
            InitializeComponent();
        }

        private void AgregarCliente_Load(object sender, EventArgs e)
        {
            query = @"select distinct Cliente_Identificador,NombreSegmento,NombreRegion, NombreCiudad, NombreEstado , NombrePais 
                from VW_DatosSuperMarket";
            DataGridView1.DataSource = Connection.SelectQuery(query);

            Connection.LlenarCB("exec LlenarCbCiudad", CbCiudad);
            Connection.LlenarCB("exec LlenarCbEstado", CbEstado);
            Connection.LlenarCB("exec LlenarCbPais", CbPais);


        }

        private void Button1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(TxtFiltro.Text) || string.IsNullOrWhiteSpace(CbRegion.Text))
            {
                Interaction.MsgBox("Por favor, revise que todos los campos estén llenos");
                return;
            }

            string ClienteID = TxtFiltro.Text;

            int UsuarioCrea = Conversions.ToInteger(TxtIdcrea.Text);

            Connection.AgregarCliente(ClienteID, UsuarioCrea);
        }

        private void Label7_Click(object sender, EventArgs e)
        {

        }

        private void ComboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataGridView1.DataSource = Connection.SelectQuery("exec llenarDtCliente '" + ObtenerPais() + "','" + ObtenerEstado() + "','" + ObtenerCiudad() + "','" + ObtenerRegion() + "','" + TxtFiltro.Text + "'");
        }

        private void CbCiudad_SelectedIndexChanged(object sender, EventArgs e)
        {
            CbRegion.Items.Clear();
            Connection.LlenarCB("exec LlenarCbRegion " + ObtenerCiudad(), CbRegion);
            DataGridView1.DataSource = Connection.SelectQuery("exec llenarDtCliente '" + ObtenerPais() + "','" + ObtenerEstado() + "','" + ObtenerCiudad() + "','" + ObtenerRegion() + "','" + TxtFiltro.Text + "'");

        }
        public string ObtenerPais()
        {
            var P = default(string);
            if (CbPais.SelectedIndex >= 0)
            {
                P = ((ObtenerId)CbPais.Items[CbPais.SelectedIndex]).ItemData;
            }

            return P;
        }
        public string ObtenerRegion()
        {
            var P = default(string);
            if (CbRegion.SelectedIndex >= 0)
            {
                P = ((ObtenerId)CbRegion.Items[CbRegion.SelectedIndex]).ItemData;
            }
            return P;
        }
        public string ObtenerEstado()
        {
            var P = default(string);
            if (CbEstado.SelectedIndex >= 0)
            {
                P = ((ObtenerId)CbEstado.Items[CbEstado.SelectedIndex]).ItemData;
            }
            return P;
        }
        public string ObtenerCiudad()
        {
            var P = default(string);
            if (CbCiudad.SelectedIndex >= 0)
            {
                P = ((ObtenerId)CbCiudad.Items[CbCiudad.SelectedIndex]).ItemData;
            }
            return P;
        }

        private void CbEstado_SelectedIndexChanged(object sender, EventArgs e)
        {
            Interaction.MsgBox(ObtenerEstado());
            DataGridView1.DataSource = Connection.SelectQuery("exec llenarDtCliente '" + ObtenerPais() + "','" + ObtenerEstado() + "','" + ObtenerCiudad() + "','" + ObtenerRegion() + "','" + TxtFiltro.Text + "'");

        }

        private void CbRegion_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataGridView1.DataSource = Connection.SelectQuery("exec llenarDtCliente '" + ObtenerPais() + "','" + ObtenerEstado() + "','" + ObtenerCiudad() + "','" + ObtenerRegion() + "','" + TxtFiltro.Text + "'");

        }

        private void TxtFiltro_KeyUp(object sender, KeyEventArgs e)
        {
            DataGridView1.DataSource = Connection.SelectQuery("exec llenarDtCliente '" + ObtenerPais() + "','" + ObtenerEstado() + "','" + ObtenerCiudad() + "','" + ObtenerRegion() + "','" + TxtFiltro.Text + "'");

        }

        private void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void PictureBox2_Click(object sender, EventArgs e)
        {
            TxtFiltro.Clear();
            CbCiudad.Items.Clear();
            CbEstado.Items.Clear();
            CbRegion.Items.Clear();
            CbPais.Items.Clear();
            CbSegmento.Items.Clear();
            TxtIdcrea.Clear();


        }
    }
}