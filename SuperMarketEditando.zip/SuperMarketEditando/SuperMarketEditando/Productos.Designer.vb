﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Productos
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Productos))
        DataGridView1 = New DataGridView()
        Panel1 = New Panel()
        PictureBox3 = New PictureBox()
        PictureBox2 = New PictureBox()
        ComboBox2 = New ComboBox()
        Label4 = New Label()
        Panel2 = New Panel()
        PictureBox1 = New PictureBox()
        TxtDate = New DateTimePicker()
        TxtUser = New TextBox()
        BtnEliminarProd = New PictureBox()
        BtnEditarProducto = New Button()
        BtnAgregarProd = New Button()
        Label3 = New Label()
        Label2 = New Label()
        Label1 = New Label()
        TxtNombreProducto = New TextBox()
        TxtProductID = New TextBox()
        CType(DataGridView1, ComponentModel.ISupportInitialize).BeginInit()
        Panel1.SuspendLayout()
        CType(PictureBox3, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox2, ComponentModel.ISupportInitialize).BeginInit()
        Panel2.SuspendLayout()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        CType(BtnEliminarProd, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' DataGridView1
        ' 
        DataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridView1.Location = New Point(5, 71)
        DataGridView1.Name = "DataGridView1"
        DataGridView1.Size = New Size(474, 372)
        DataGridView1.TabIndex = 0
        ' 
        ' Panel1
        ' 
        Panel1.Controls.Add(PictureBox3)
        Panel1.Controls.Add(PictureBox2)
        Panel1.Controls.Add(ComboBox2)
        Panel1.Controls.Add(Label4)
        Panel1.Location = New Point(-5, 1)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(794, 64)
        Panel1.TabIndex = 1
        ' 
        ' PictureBox3
        ' 
        PictureBox3.Image = CType(resources.GetObject("PictureBox3.Image"), Image)
        PictureBox3.Location = New Point(720, 17)
        PictureBox3.Name = "PictureBox3"
        PictureBox3.Size = New Size(30, 33)
        PictureBox3.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox3.TabIndex = 17
        PictureBox3.TabStop = False
        ' 
        ' PictureBox2
        ' 
        PictureBox2.Image = CType(resources.GetObject("PictureBox2.Image"), Image)
        PictureBox2.Location = New Point(471, 17)
        PictureBox2.Name = "PictureBox2"
        PictureBox2.Size = New Size(31, 28)
        PictureBox2.SizeMode = PictureBoxSizeMode.Zoom
        PictureBox2.TabIndex = 16
        PictureBox2.TabStop = False
        ' 
        ' ComboBox2
        ' 
        ComboBox2.FormattingEnabled = True
        ComboBox2.Location = New Point(232, 21)
        ComboBox2.Name = "ComboBox2"
        ComboBox2.Size = New Size(223, 23)
        ComboBox2.TabIndex = 15
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Location = New Point(43, 24)
        Label4.Name = "Label4"
        Label4.Size = New Size(61, 15)
        Label4.TabIndex = 14
        Label4.Text = "Productos"
        ' 
        ' Panel2
        ' 
        Panel2.Controls.Add(PictureBox1)
        Panel2.Controls.Add(TxtDate)
        Panel2.Controls.Add(TxtUser)
        Panel2.Controls.Add(BtnEliminarProd)
        Panel2.Controls.Add(BtnEditarProducto)
        Panel2.Controls.Add(BtnAgregarProd)
        Panel2.Controls.Add(Label3)
        Panel2.Controls.Add(Label2)
        Panel2.Controls.Add(Label1)
        Panel2.Controls.Add(TxtNombreProducto)
        Panel2.Controls.Add(TxtProductID)
        Panel2.Location = New Point(484, 71)
        Panel2.Name = "Panel2"
        Panel2.Size = New Size(301, 373)
        Panel2.TabIndex = 2
        ' 
        ' PictureBox1
        ' 
        PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), Image)
        PictureBox1.Location = New Point(175, 304)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(40, 40)
        PictureBox1.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox1.TabIndex = 16
        PictureBox1.TabStop = False
        ' 
        ' TxtDate
        ' 
        TxtDate.Format = DateTimePickerFormat.Short
        TxtDate.Location = New Point(92, 233)
        TxtDate.Name = "TxtDate"
        TxtDate.Size = New Size(140, 23)
        TxtDate.TabIndex = 15
        ' 
        ' TxtUser
        ' 
        TxtUser.Location = New Point(63, 204)
        TxtUser.Name = "TxtUser"
        TxtUser.Size = New Size(169, 23)
        TxtUser.TabIndex = 14
        ' 
        ' BtnEliminarProd
        ' 
        BtnEliminarProd.Image = CType(resources.GetObject("BtnEliminarProd.Image"), Image)
        BtnEliminarProd.Location = New Point(92, 304)
        BtnEliminarProd.Name = "BtnEliminarProd"
        BtnEliminarProd.Size = New Size(42, 40)
        BtnEliminarProd.SizeMode = PictureBoxSizeMode.StretchImage
        BtnEliminarProd.TabIndex = 13
        BtnEliminarProd.TabStop = False
        ' 
        ' BtnEditarProducto
        ' 
        BtnEditarProducto.Location = New Point(175, 264)
        BtnEditarProducto.Name = "BtnEditarProducto"
        BtnEditarProducto.Size = New Size(75, 23)
        BtnEditarProducto.TabIndex = 12
        BtnEditarProducto.Text = "Modificar"
        BtnEditarProducto.UseVisualStyleBackColor = True
        ' 
        ' BtnAgregarProd
        ' 
        BtnAgregarProd.Location = New Point(40, 264)
        BtnAgregarProd.Name = "BtnAgregarProd"
        BtnAgregarProd.Size = New Size(75, 23)
        BtnAgregarProd.TabIndex = 11
        BtnAgregarProd.Text = "Agregar"
        BtnAgregarProd.UseVisualStyleBackColor = True
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Location = New Point(119, 186)
        Label3.Name = "Label3"
        Label3.Size = New Size(47, 15)
        Label3.TabIndex = 5
        Label3.Text = "Usuario"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Location = New Point(110, 54)
        Label2.Name = "Label2"
        Label2.Size = New Size(70, 15)
        Label2.TabIndex = 4
        Label2.Text = "Producto ID"
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Location = New Point(82, 116)
        Label1.Name = "Label1"
        Label1.Size = New Size(122, 15)
        Label1.TabIndex = 3
        Label1.Text = "Nombre del Producto"
        ' 
        ' TxtNombreProducto
        ' 
        TxtNombreProducto.Location = New Point(63, 143)
        TxtNombreProducto.Name = "TxtNombreProducto"
        TxtNombreProducto.Size = New Size(169, 23)
        TxtNombreProducto.TabIndex = 1
        ' 
        ' TxtProductID
        ' 
        TxtProductID.Location = New Point(63, 81)
        TxtProductID.Name = "TxtProductID"
        TxtProductID.Size = New Size(169, 23)
        TxtProductID.TabIndex = 0
        ' 
        ' Productos
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(788, 452)
        Controls.Add(Panel2)
        Controls.Add(Panel1)
        Controls.Add(DataGridView1)
        Name = "Productos"
        Text = "Productos"
        CType(DataGridView1, ComponentModel.ISupportInitialize).EndInit()
        Panel1.ResumeLayout(False)
        Panel1.PerformLayout()
        CType(PictureBox3, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox2, ComponentModel.ISupportInitialize).EndInit()
        Panel2.ResumeLayout(False)
        Panel2.PerformLayout()
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        CType(BtnEliminarProd, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
    End Sub

    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Panel2 As Panel
    Friend WithEvents TxtNombreProducto As TextBox
    Friend WithEvents TxtProductID As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents BtnEliminarProd As PictureBox
    Friend WithEvents BtnEditarProducto As Button
    Friend WithEvents BtnAgregarProd As Button
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents ComboBox2 As ComboBox
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents TxtUser As TextBox
    Friend WithEvents TxtDate As DateTimePicker
    Friend WithEvents PictureBox1 As PictureBox
End Class
