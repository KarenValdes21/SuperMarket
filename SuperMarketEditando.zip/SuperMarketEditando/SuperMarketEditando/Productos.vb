﻿Imports System.Data.SqlClient
Imports NSubstitute.Core

Public Class Productos
    Dim query As String
    Private Sub Productos_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        query = "select * from producto;"
        DataGridView1.DataSource = Connection.SelectQuery(query)

    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub

    Public Sub LoadD()
        Try
            query = "select * from producto"
            DataGridView1.DataSource = Connection.SelectQuery(query)
        Catch ex As Exception
            MsgBox("Ha ocurrido un error: " & ex.Message)
        End Try
    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles BtnEliminarProd.Click
        If String.IsNullOrWhiteSpace(Me.TxtProductID.Text) Then
            MsgBox("Por favor, revise que todos los campos estén llenos")
            Return
        End If

        Dim ProductID As String = Me.TxtProductID.Text

        Connection.EliminarProducto(ProductID.ToString)
    End Sub
    Public SelectedProduct As String
    Private Sub PictureBox2_Click(sender As Object, e As EventArgs) Handles PictureBox2.Click

        query = "SELECT id, [NombreProducto] FROM Producto WHERE NombreProducto = '" & SelectedProduct.Replace("'", "''") & "'"
        DataGridView1.DataSource = Connection.SelectQuery(query)
    End Sub

    Private Sub ComboBox2_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox2.SelectedIndexChanged
        SelectedProduct = ComboBox2.Text
    End Sub

    Private Sub PictureBox3_Click(sender As Object, e As EventArgs) Handles PictureBox3.Click
        LoadD()

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles BtnAgregarProd.Click
        If String.IsNullOrWhiteSpace(TxtProductID.Text) OrElse
    String.IsNullOrWhiteSpace(TxtNombreProducto.Text) Then
            MsgBox("Por favor, revise que todos los campos estén llenos")
            Return
        End If

        Dim ProductID As String = TxtProductID.Text
        Dim NombreProducto As String = TxtNombreProducto.Text
        Dim UsuarioCrea As Integer = TxtUser.Text

        Connection.AgregarProducto(ProductID, NombreProducto, UsuarioCrea)
    End Sub

    Private Sub BtnEditarProducto_Click(sender As Object, e As EventArgs) Handles BtnEditarProducto.Click
        If String.IsNullOrWhiteSpace(TxtProductID.Text) OrElse
String.IsNullOrWhiteSpace(TxtNombreProducto.Text) Then
            MsgBox("Por favor, revise que todos los campos estén llenos")
            Return
        End If

        Dim ProductID As String = TxtProductID.Text
        Dim NombreProducto As String = TxtNombreProducto.Text
        Dim UsuarioCrea As Integer = TxtUser.Text
        Dim fechaMod As Date = Convert.ToDateTime(txtDate.Text)

        Connection.EditarProducto(ProductID, NombreProducto, UsuarioCrea, fechaMod)
    End Sub

    Private Sub PictureBox1_Click_1(sender As Object, e As EventArgs) Handles PictureBox1.Click
        TxtProductID.Clear()
        TxtNombreProducto.Clear()
        TxtUser.Clear()

    End Sub
End Class