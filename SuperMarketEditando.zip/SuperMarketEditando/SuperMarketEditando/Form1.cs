﻿using System;

namespace SuperMarketEditando
{

    public partial class Form1
    {
        private string query;

        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            query = "SELECT * FROM VW_DatosSuperMarket1;";
            DataGridView1.DataSource = Connection.SelectQuery(query);

        }


        private void Label2_Click(object sender, EventArgs e)
        {
            My.MyProject.Forms.AgregarCliente.Show();

        }

        private void Label3_Click(object sender, EventArgs e)
        {
            My.MyProject.Forms.Productos.Show();

        }

        private void PictureBox4_Click(object sender, EventArgs e)
        {

        }
    }
}