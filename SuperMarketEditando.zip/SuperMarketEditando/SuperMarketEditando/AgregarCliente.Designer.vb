﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AgregarCliente
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(AgregarCliente))
        PictureBox1 = New PictureBox()
        Button2 = New Button()
        Button1 = New Button()
        Panel1 = New Panel()
        Label1 = New Label()
        TxtFiltro = New TextBox()
        DataGridView1 = New DataGridView()
        Label2 = New Label()
        Label3 = New Label()
        Label4 = New Label()
        Label5 = New Label()
        Label6 = New Label()
        Label7 = New Label()
        CbPais = New ComboBox()
        CbEstado = New ComboBox()
        CbCiudad = New ComboBox()
        CbRegion = New ComboBox()
        CbSegmento = New ComboBox()
        TxtIdcrea = New TextBox()
        PictureBox2 = New PictureBox()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        Panel1.SuspendLayout()
        CType(DataGridView1, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox2, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' PictureBox1
        ' 
        PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), Image)
        PictureBox1.Location = New Point(494, 416)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(42, 40)
        PictureBox1.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox1.TabIndex = 10
        PictureBox1.TabStop = False
        ' 
        ' Button2
        ' 
        Button2.Location = New Point(627, 379)
        Button2.Name = "Button2"
        Button2.Size = New Size(75, 23)
        Button2.TabIndex = 9
        Button2.Text = "Modificar"
        Button2.UseVisualStyleBackColor = True
        ' 
        ' Button1
        ' 
        Button1.Location = New Point(460, 379)
        Button1.Name = "Button1"
        Button1.Size = New Size(75, 23)
        Button1.TabIndex = 8
        Button1.Text = "Agregar"
        Button1.UseVisualStyleBackColor = True
        ' 
        ' Panel1
        ' 
        Panel1.Controls.Add(Label1)
        Panel1.Location = New Point(0, 5)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(712, 61)
        Panel1.TabIndex = 7
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Location = New Point(46, 23)
        Label1.Name = "Label1"
        Label1.Size = New Size(49, 15)
        Label1.TabIndex = 0
        Label1.Text = "Clientes"
        ' 
        ' TxtFiltro
        ' 
        TxtFiltro.Location = New Point(494, 114)
        TxtFiltro.Name = "TxtFiltro"
        TxtFiltro.Size = New Size(178, 23)
        TxtFiltro.TabIndex = 1
        ' 
        ' DataGridView1
        ' 
        DataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridView1.Location = New Point(12, 72)
        DataGridView1.Name = "DataGridView1"
        DataGridView1.Size = New Size(388, 384)
        DataGridView1.TabIndex = 6
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Location = New Point(544, 85)
        Label2.Name = "Label2"
        Label2.Size = New Size(58, 15)
        Label2.TabIndex = 1
        Label2.Text = "Cliente ID"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Location = New Point(478, 155)
        Label3.Name = "Label3"
        Label3.Size = New Size(28, 15)
        Label3.TabIndex = 14
        Label3.Text = "Pais"
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Location = New Point(613, 155)
        Label4.Name = "Label4"
        Label4.Size = New Size(42, 15)
        Label4.TabIndex = 16
        Label4.Text = "Estado"
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Location = New Point(478, 219)
        Label5.Name = "Label5"
        Label5.Size = New Size(45, 15)
        Label5.TabIndex = 18
        Label5.Text = "Ciudad"
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.Location = New Point(613, 219)
        Label6.Name = "Label6"
        Label6.Size = New Size(44, 15)
        Label6.TabIndex = 20
        Label6.Text = "Region"
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.Location = New Point(553, 289)
        Label7.Name = "Label7"
        Label7.Size = New Size(61, 15)
        Label7.TabIndex = 21
        Label7.Text = "Segmento"
        ' 
        ' CbPais
        ' 
        CbPais.FormattingEnabled = True
        CbPais.Location = New Point(444, 173)
        CbPais.Name = "CbPais"
        CbPais.Size = New Size(121, 23)
        CbPais.TabIndex = 22
        ' 
        ' CbEstado
        ' 
        CbEstado.FormattingEnabled = True
        CbEstado.Location = New Point(591, 173)
        CbEstado.Name = "CbEstado"
        CbEstado.Size = New Size(121, 23)
        CbEstado.TabIndex = 23
        ' 
        ' CbCiudad
        ' 
        CbCiudad.FormattingEnabled = True
        CbCiudad.Location = New Point(444, 239)
        CbCiudad.Name = "CbCiudad"
        CbCiudad.Size = New Size(121, 23)
        CbCiudad.TabIndex = 24
        ' 
        ' CbRegion
        ' 
        CbRegion.FormattingEnabled = True
        CbRegion.Location = New Point(591, 239)
        CbRegion.Name = "CbRegion"
        CbRegion.Size = New Size(121, 23)
        CbRegion.TabIndex = 25
        ' 
        ' CbSegmento
        ' 
        CbSegmento.FormattingEnabled = True
        CbSegmento.Location = New Point(481, 307)
        CbSegmento.Name = "CbSegmento"
        CbSegmento.Size = New Size(207, 23)
        CbSegmento.TabIndex = 26
        ' 
        ' TxtIdcrea
        ' 
        TxtIdcrea.Location = New Point(525, 350)
        TxtIdcrea.Name = "TxtIdcrea"
        TxtIdcrea.Size = New Size(100, 23)
        TxtIdcrea.TabIndex = 27
        ' 
        ' PictureBox2
        ' 
        PictureBox2.Image = CType(resources.GetObject("PictureBox2.Image"), Image)
        PictureBox2.Location = New Point(617, 416)
        PictureBox2.Name = "PictureBox2"
        PictureBox2.Size = New Size(40, 40)
        PictureBox2.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox2.TabIndex = 28
        PictureBox2.TabStop = False
        ' 
        ' AgregarCliente
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(724, 468)
        Controls.Add(PictureBox2)
        Controls.Add(TxtIdcrea)
        Controls.Add(TxtFiltro)
        Controls.Add(CbSegmento)
        Controls.Add(CbRegion)
        Controls.Add(CbCiudad)
        Controls.Add(CbEstado)
        Controls.Add(CbPais)
        Controls.Add(Label7)
        Controls.Add(Label6)
        Controls.Add(Label5)
        Controls.Add(Label4)
        Controls.Add(Label3)
        Controls.Add(Label2)
        Controls.Add(PictureBox1)
        Controls.Add(Button2)
        Controls.Add(Button1)
        Controls.Add(Panel1)
        Controls.Add(DataGridView1)
        Name = "AgregarCliente"
        Text = "AgregarCliente"
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        Panel1.ResumeLayout(False)
        Panel1.PerformLayout()
        CType(DataGridView1, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox2, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Button2 As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Label1 As Label
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents CbPais As ComboBox
    Friend WithEvents CbEstado As ComboBox
    Friend WithEvents CbCiudad As ComboBox
    Friend WithEvents CbRegion As ComboBox
    Friend WithEvents CbSegmento As ComboBox
    Friend WithEvents TxtFiltro As TextBox
    Friend WithEvents TxtIdcrea As TextBox
    Friend WithEvents PictureBox2 As PictureBox
End Class
