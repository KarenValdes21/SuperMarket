﻿using System;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;

namespace SuperMarketEditando
{

    public partial class Productos
    {
        private string query;

        public Productos()
        {
            InitializeComponent();
        }
        private void Productos_Load(object sender, EventArgs e)
        {
            query = "select * from producto;";
            DataGridView1.DataSource = Connection.SelectQuery(query);

        }

        private void Label1_Click(object sender, EventArgs e)
        {

        }

        private void DataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        public void LoadD()
        {
            try
            {
                query = "select * from producto";
                DataGridView1.DataSource = Connection.SelectQuery(query);
            }
            catch (Exception ex)
            {
                Interaction.MsgBox("Ha ocurrido un error: " + ex.Message);
            }
        }

        private void PictureBox1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(TxtProductID.Text))
            {
                Interaction.MsgBox("Por favor, revise que todos los campos estén llenos");
                return;
            }

            string ProductID = TxtProductID.Text;

            Connection.EliminarProducto(ProductID.ToString());
        }
        public string SelectedProduct;
        private void PictureBox2_Click(object sender, EventArgs e)
        {

            query = "SELECT id, [NombreProducto] FROM Producto WHERE NombreProducto = '" + SelectedProduct.Replace("'", "''") + "'";
            DataGridView1.DataSource = Connection.SelectQuery(query);
        }

        private void ComboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            SelectedProduct = ComboBox2.Text;
        }

        private void PictureBox3_Click(object sender, EventArgs e)
        {
            LoadD();

        }

        private void Button1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(TxtProductID.Text) || string.IsNullOrWhiteSpace(TxtNombreProducto.Text))
            {
                Interaction.MsgBox("Por favor, revise que todos los campos estén llenos");
                return;
            }

            string ProductID = TxtProductID.Text;
            string NombreProducto = TxtNombreProducto.Text;
            int UsuarioCrea = Conversions.ToInteger(TxtUser.Text);

            Connection.AgregarProducto(ProductID, NombreProducto, UsuarioCrea);
        }

        private void BtnEditarProducto_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(TxtProductID.Text) || string.IsNullOrWhiteSpace(TxtNombreProducto.Text))
            {
                Interaction.MsgBox("Por favor, revise que todos los campos estén llenos");
                return;
            }

            string ProductID = TxtProductID.Text;
            string NombreProducto = TxtNombreProducto.Text;
            int UsuarioCrea = Conversions.ToInteger(TxtUser.Text);
            var fechaMod = Convert.ToDateTime(TxtDate.Text);

            Connection.EditarProducto(ProductID, NombreProducto, UsuarioCrea, fechaMod);
        }

        private void PictureBox1_Click_1(object sender, EventArgs e)
        {
            TxtProductID.Clear();
            TxtNombreProducto.Clear();
            TxtUser.Clear();

        }
    }
}