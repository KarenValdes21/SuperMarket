﻿Imports System.Data.SqlClient

Public Class Connection
    Shared cnx As New SqlConnection
    Public cmd As SqlClient.SqlCommand
    Public sqlread As SqlClient.SqlDataReader
    Public Query As String
    Private Shared Sub Connect()
        Try
            cnx.ConnectionString = "Data Source=LAPTOP-RRR3K3KV; Initial Catalog=SuperMarketPrueba2 ;Integrated Security=True"
            cnx.Open()
        Catch ex As Exception
            MsgBox("Error al conectar a la base de datos: " & ex.Message)
        End Try
    End Sub
    Private Shared Sub Disconect()
        Try
            If cnx.State = ConnectionState.Open Then
                cnx.Close()
            End If
        Catch ex As Exception
            MsgBox("Error al desconectar de la base de datos: " & ex.Message)
        End Try
    End Sub
    Public Shared Function SelectQuery(ByVal query As String, Optional parameters As Dictionary(Of String, Object) = Nothing) As DataTable
        Dim dt As New DataTable
        Try
            Connect()
            Dim cmd As New SqlCommand(query, cnx)
            Dim da As New SqlDataAdapter(cmd)
            da.Fill(dt)
        Catch ex As Exception
            MsgBox("Error al ejecutar la consulta: " & ex.Message)
        Finally
            Disconect()
        End Try
        Return dt
    End Function

    Public Shared Sub LlenarCB(ByVal query As String, Cb As ComboBox)
        Dim sqlread As SqlClient.SqlDataReader
        Connect()
        Dim cmd = New SqlCommand(query, cnx)
        cmd.ExecuteNonQuery()
        sqlread = cmd.ExecuteReader
        While sqlread.Read
            Cb.Items.Add(New ObtenerId(sqlread("Nombre"), sqlread("id"))).ToString()
        End While
        Disconect()
        sqlread.Close()
    End Sub


    Public Shared Sub EliminarProducto(ByVal ProductID As String)
        Try
            Connect()
            Dim cmd As New SqlCommand("SP_EliminarProducto", cnx)
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.Add("@ProductoID", SqlDbType.VarChar).Value = ProductID.ToString

            cmd.ExecuteNonQuery()

            MsgBox("Registro eliminado con éxito")
        Catch ex As Exception
            MsgBox("Error al eliminar el registro " & ex.Message)
        Finally
            Disconect()
        End Try
    End Sub

    Public Shared Sub AgregarProducto(ByVal ProductID As String, ByVal NombreProducto As String, ByVal UsuarioCrea As Integer)
        Try
            Connect()
            Dim cmd As New SqlCommand("SP_AgregarProducto", cnx)
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.AddWithValue("@ProductoID", SqlDbType.VarChar).Value = ProductID.ToString
            cmd.Parameters.AddWithValue("@NombreProducto", SqlDbType.VarChar).Value = NombreProducto.ToString
            cmd.Parameters.AddWithValue("@IdUsuarioCrea", UsuarioCrea)


            cmd.ExecuteNonQuery()

            MsgBox("Producto insertado con éxito")
        Catch ex As Exception
            MsgBox("Error al insertar el Producto " & ex.Message)
        Finally
            Disconect()
        End Try
    End Sub
    Public Shared Sub EditarProducto(ByVal ProductID As String, ByVal NombreProducto As String, ByVal UsuarioCrea As Integer, ByVal FechaModifica As Date)
        Try
            Connect()
            Dim cmd As New SqlCommand("SP_EditarProducto", cnx)
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.AddWithValue("@ProductoID", SqlDbType.VarChar).Value = ProductID.ToString
            cmd.Parameters.AddWithValue("@NuevoNombreProducto", SqlDbType.VarChar).Value = NombreProducto.ToString
            cmd.Parameters.AddWithValue("@NuevoIdUsuarioModifica", UsuarioCrea)
            cmd.Parameters.AddWithValue("@fechaModifica", FechaModifica)
            cmd.ExecuteNonQuery()


            MsgBox("Producto editado con éxito")
        Catch ex As Exception
            MsgBox("Error al editar el registro " & ex.Message)
        Finally
            Disconect()
        End Try
    End Sub
    Public Shared Sub AgregarCliente(ByVal ClienteID As String,
                                      ByVal UsuarioCrea As Integer)
        Try
            Connect()
            Dim cmd As New SqlCommand("SPAgregarCliente", cnx)
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.AddWithValue("@ClienteID", SqlDbType.VarChar).Value = ClienteID.ToString

            cmd.Parameters.AddWithValue("@IdUsuarioCrea", UsuarioCrea)


            cmd.ExecuteNonQuery()

            MsgBox("Producto insertado con éxito")
        Catch ex As Exception
            MsgBox("Error al insertar el Producto " & ex.Message)
        Finally
            Disconect()
        End Try
    End Sub

End Class
