﻿using System;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;

namespace SuperMarketEditando
{
    [Microsoft.VisualBasic.CompilerServices.DesignerGenerated()]
    public partial class Form1 : Form
    {

        // Form overrides dispose to clean up the component list.
        [DebuggerNonUserCode()]
        protected override void Dispose(bool disposing)
        {
            try
            {
                if (disposing && components is not null)
                {
                    components.Dispose();
                }
            }
            finally
            {
                base.Dispose(disposing);
            }
        }

        // Required by the Windows Form Designer
        private System.ComponentModel.IContainer components;

        // NOTE: The following procedure is required by the Windows Form Designer
        // It can be modified using the Windows Form Designer.  
        // Do not modify it using the code editor.
        [DebuggerStepThrough()]
        private void InitializeComponent()
        {
            var resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            DataGridView1 = new DataGridView();
            Label1 = new Label();
            PictureBox1 = new PictureBox();
            ComboBox1 = new ComboBox();
            Panel1 = new Panel();
            Label3 = new Label();
            Label3.Click += new EventHandler(Label3_Click);
            Label2 = new Label();
            Label2.Click += new EventHandler(Label2_Click);
            PictureBox2 = new PictureBox();
            Panel2 = new Panel();
            PictureBox4 = new PictureBox();
            PictureBox4.Click += new EventHandler(PictureBox4_Click);
            ((System.ComponentModel.ISupportInitialize)DataGridView1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)PictureBox1).BeginInit();
            Panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)PictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)PictureBox4).BeginInit();
            SuspendLayout();
            // 
            // DataGridView1
            // 
            DataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            DataGridView1.Location = new Point(173, 122);
            DataGridView1.Name = "DataGridView1";
            DataGridView1.Size = new Size(356, 285);
            DataGridView1.TabIndex = 0;
            // 
            // Label1
            // 
            Label1.AutoSize = true;
            Label1.Location = new Point(173, 74);
            Label1.Name = "Label1";
            Label1.Size = new Size(44, 15);
            Label1.TabIndex = 2;
            Label1.Text = "Pedido";
            // 
            // PictureBox1
            // 
            PictureBox1.Image = (Image)resources.GetObject("PictureBox1.Image");
            PictureBox1.Location = new Point(484, 64);
            PictureBox1.Name = "PictureBox1";
            PictureBox1.Size = new Size(33, 34);
            PictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            PictureBox1.TabIndex = 3;
            PictureBox1.TabStop = false;
            // 
            // ComboBox1
            // 
            ComboBox1.FormattingEnabled = true;
            ComboBox1.Location = new Point(249, 71);
            ComboBox1.Name = "ComboBox1";
            ComboBox1.Size = new Size(207, 23);
            ComboBox1.TabIndex = 4;
            // 
            // Panel1
            // 
            Panel1.Controls.Add(Label3);
            Panel1.Controls.Add(Label2);
            Panel1.Controls.Add(PictureBox2);
            Panel1.Location = new Point(0, 48);
            Panel1.Name = "Panel1";
            Panel1.Size = new Size(147, 386);
            Panel1.TabIndex = 5;
            // 
            // Label3
            // 
            Label3.AutoSize = true;
            Label3.Location = new Point(12, 111);
            Label3.Name = "Label3";
            Label3.Size = new Size(61, 15);
            Label3.TabIndex = 5;
            Label3.Text = "Productos";
            // 
            // Label2
            // 
            Label2.AutoSize = true;
            Label2.Location = new Point(12, 57);
            Label2.Name = "Label2";
            Label2.Size = new Size(44, 15);
            Label2.TabIndex = 4;
            Label2.Text = "Cliente";
            // 
            // PictureBox2
            // 
            PictureBox2.Location = new Point(104, 48);
            PictureBox2.Name = "PictureBox2";
            PictureBox2.Size = new Size(35, 37);
            PictureBox2.TabIndex = 3;
            PictureBox2.TabStop = false;
            // 
            // Panel2
            // 
            Panel2.Location = new Point(0, 1);
            Panel2.Name = "Panel2";
            Panel2.Size = new Size(628, 49);
            Panel2.TabIndex = 6;
            // 
            // PictureBox4
            // 
            PictureBox4.Image = (Image)resources.GetObject("PictureBox4.Image");
            PictureBox4.Location = new Point(547, 216);
            PictureBox4.Name = "PictureBox4";
            PictureBox4.Size = new Size(47, 46);
            PictureBox4.SizeMode = PictureBoxSizeMode.StretchImage;
            PictureBox4.TabIndex = 8;
            PictureBox4.TabStop = false;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7f, 15f);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(623, 436);
            Controls.Add(PictureBox4);
            Controls.Add(Panel2);
            Controls.Add(Panel1);
            Controls.Add(ComboBox1);
            Controls.Add(PictureBox1);
            Controls.Add(Label1);
            Controls.Add(DataGridView1);
            Name = "Form1";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)DataGridView1).EndInit();
            ((System.ComponentModel.ISupportInitialize)PictureBox1).EndInit();
            Panel1.ResumeLayout(false);
            Panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)PictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)PictureBox4).EndInit();
            Load += new EventHandler(Form1_Load);
            ResumeLayout(false);
            PerformLayout();
        }

        internal DataGridView DataGridView1;
        internal Label Label1;
        internal PictureBox PictureBox1;
        internal ComboBox ComboBox1;
        internal Panel Panel1;
        internal PictureBox PictureBox2;
        internal Panel Panel2;
        internal PictureBox PictureBox4;
        internal Label Label2;
        internal Label Label3;

    }
}