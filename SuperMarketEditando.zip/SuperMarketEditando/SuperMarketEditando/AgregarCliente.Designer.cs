﻿using System;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;

namespace SuperMarketEditando
{
    [Microsoft.VisualBasic.CompilerServices.DesignerGenerated()]
    public partial class AgregarCliente : Form
    {

        // Form reemplaza a Dispose para limpiar la lista de componentes.
        [DebuggerNonUserCode()]
        protected override void Dispose(bool disposing)
        {
            try
            {
                if (disposing && components is not null)
                {
                    components.Dispose();
                }
            }
            finally
            {
                base.Dispose(disposing);
            }
        }

        // Requerido por el Diseñador de Windows Forms
        private System.ComponentModel.IContainer components;

        // NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
        // Se puede modificar usando el Diseñador de Windows Forms.  
        // No lo modifique con el editor de código.
        [DebuggerStepThrough()]
        private void InitializeComponent()
        {
            var resources = new System.ComponentModel.ComponentResourceManager(typeof(AgregarCliente));
            PictureBox1 = new PictureBox();
            Button2 = new Button();
            Button1 = new Button();
            Button1.Click += new EventHandler(Button1_Click);
            Panel1 = new Panel();
            Label1 = new Label();
            TxtFiltro = new TextBox();
            TxtFiltro.KeyUp += new KeyEventHandler(TxtFiltro_KeyUp);
            DataGridView1 = new DataGridView();
            Label2 = new Label();
            Label3 = new Label();
            Label4 = new Label();
            Label5 = new Label();
            Label6 = new Label();
            Label7 = new Label();
            Label7.Click += new EventHandler(Label7_Click);
            CbPais = new ComboBox();
            CbPais.SelectedIndexChanged += new EventHandler(ComboBox1_SelectedIndexChanged);
            CbEstado = new ComboBox();
            CbEstado.SelectedIndexChanged += new EventHandler(CbEstado_SelectedIndexChanged);
            CbCiudad = new ComboBox();
            CbCiudad.SelectedIndexChanged += new EventHandler(CbCiudad_SelectedIndexChanged);
            CbRegion = new ComboBox();
            CbRegion.SelectedIndexChanged += new EventHandler(CbRegion_SelectedIndexChanged);
            CbSegmento = new ComboBox();
            TxtIdcrea = new TextBox();
            PictureBox2 = new PictureBox();
            PictureBox2.Click += new EventHandler(PictureBox2_Click);
            ((System.ComponentModel.ISupportInitialize)PictureBox1).BeginInit();
            Panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)DataGridView1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)PictureBox2).BeginInit();
            SuspendLayout();
            // 
            // PictureBox1
            // 
            PictureBox1.Image = (Image)resources.GetObject("PictureBox1.Image");
            PictureBox1.Location = new Point(494, 416);
            PictureBox1.Name = "PictureBox1";
            PictureBox1.Size = new Size(42, 40);
            PictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            PictureBox1.TabIndex = 10;
            PictureBox1.TabStop = false;
            // 
            // Button2
            // 
            Button2.Location = new Point(627, 379);
            Button2.Name = "Button2";
            Button2.Size = new Size(75, 23);
            Button2.TabIndex = 9;
            Button2.Text = "Modificar";
            Button2.UseVisualStyleBackColor = true;
            // 
            // Button1
            // 
            Button1.Location = new Point(460, 379);
            Button1.Name = "Button1";
            Button1.Size = new Size(75, 23);
            Button1.TabIndex = 8;
            Button1.Text = "Agregar";
            Button1.UseVisualStyleBackColor = true;
            // 
            // Panel1
            // 
            Panel1.Controls.Add(Label1);
            Panel1.Location = new Point(0, 5);
            Panel1.Name = "Panel1";
            Panel1.Size = new Size(712, 61);
            Panel1.TabIndex = 7;
            // 
            // Label1
            // 
            Label1.AutoSize = true;
            Label1.Location = new Point(46, 23);
            Label1.Name = "Label1";
            Label1.Size = new Size(49, 15);
            Label1.TabIndex = 0;
            Label1.Text = "Clientes";
            // 
            // TxtFiltro
            // 
            TxtFiltro.Location = new Point(494, 114);
            TxtFiltro.Name = "TxtFiltro";
            TxtFiltro.Size = new Size(178, 23);
            TxtFiltro.TabIndex = 1;
            // 
            // DataGridView1
            // 
            DataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            DataGridView1.Location = new Point(12, 72);
            DataGridView1.Name = "DataGridView1";
            DataGridView1.Size = new Size(388, 384);
            DataGridView1.TabIndex = 6;
            // 
            // Label2
            // 
            Label2.AutoSize = true;
            Label2.Location = new Point(544, 85);
            Label2.Name = "Label2";
            Label2.Size = new Size(58, 15);
            Label2.TabIndex = 1;
            Label2.Text = "Cliente ID";
            // 
            // Label3
            // 
            Label3.AutoSize = true;
            Label3.Location = new Point(478, 155);
            Label3.Name = "Label3";
            Label3.Size = new Size(28, 15);
            Label3.TabIndex = 14;
            Label3.Text = "Pais";
            // 
            // Label4
            // 
            Label4.AutoSize = true;
            Label4.Location = new Point(613, 155);
            Label4.Name = "Label4";
            Label4.Size = new Size(42, 15);
            Label4.TabIndex = 16;
            Label4.Text = "Estado";
            // 
            // Label5
            // 
            Label5.AutoSize = true;
            Label5.Location = new Point(478, 219);
            Label5.Name = "Label5";
            Label5.Size = new Size(45, 15);
            Label5.TabIndex = 18;
            Label5.Text = "Ciudad";
            // 
            // Label6
            // 
            Label6.AutoSize = true;
            Label6.Location = new Point(613, 219);
            Label6.Name = "Label6";
            Label6.Size = new Size(44, 15);
            Label6.TabIndex = 20;
            Label6.Text = "Region";
            // 
            // Label7
            // 
            Label7.AutoSize = true;
            Label7.Location = new Point(553, 289);
            Label7.Name = "Label7";
            Label7.Size = new Size(61, 15);
            Label7.TabIndex = 21;
            Label7.Text = "Segmento";
            // 
            // CbPais
            // 
            CbPais.FormattingEnabled = true;
            CbPais.Location = new Point(444, 173);
            CbPais.Name = "CbPais";
            CbPais.Size = new Size(121, 23);
            CbPais.TabIndex = 22;
            // 
            // CbEstado
            // 
            CbEstado.FormattingEnabled = true;
            CbEstado.Location = new Point(591, 173);
            CbEstado.Name = "CbEstado";
            CbEstado.Size = new Size(121, 23);
            CbEstado.TabIndex = 23;
            // 
            // CbCiudad
            // 
            CbCiudad.FormattingEnabled = true;
            CbCiudad.Location = new Point(444, 239);
            CbCiudad.Name = "CbCiudad";
            CbCiudad.Size = new Size(121, 23);
            CbCiudad.TabIndex = 24;
            // 
            // CbRegion
            // 
            CbRegion.FormattingEnabled = true;
            CbRegion.Location = new Point(591, 239);
            CbRegion.Name = "CbRegion";
            CbRegion.Size = new Size(121, 23);
            CbRegion.TabIndex = 25;
            // 
            // CbSegmento
            // 
            CbSegmento.FormattingEnabled = true;
            CbSegmento.Location = new Point(481, 307);
            CbSegmento.Name = "CbSegmento";
            CbSegmento.Size = new Size(207, 23);
            CbSegmento.TabIndex = 26;
            // 
            // TxtIdcrea
            // 
            TxtIdcrea.Location = new Point(525, 350);
            TxtIdcrea.Name = "TxtIdcrea";
            TxtIdcrea.Size = new Size(100, 23);
            TxtIdcrea.TabIndex = 27;
            // 
            // PictureBox2
            // 
            PictureBox2.Image = (Image)resources.GetObject("PictureBox2.Image");
            PictureBox2.Location = new Point(617, 416);
            PictureBox2.Name = "PictureBox2";
            PictureBox2.Size = new Size(40, 40);
            PictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            PictureBox2.TabIndex = 28;
            PictureBox2.TabStop = false;
            // 
            // AgregarCliente
            // 
            AutoScaleDimensions = new SizeF(7f, 15f);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(724, 468);
            Controls.Add(PictureBox2);
            Controls.Add(TxtIdcrea);
            Controls.Add(TxtFiltro);
            Controls.Add(CbSegmento);
            Controls.Add(CbRegion);
            Controls.Add(CbCiudad);
            Controls.Add(CbEstado);
            Controls.Add(CbPais);
            Controls.Add(Label7);
            Controls.Add(Label6);
            Controls.Add(Label5);
            Controls.Add(Label4);
            Controls.Add(Label3);
            Controls.Add(Label2);
            Controls.Add(PictureBox1);
            Controls.Add(Button2);
            Controls.Add(Button1);
            Controls.Add(Panel1);
            Controls.Add(DataGridView1);
            Name = "AgregarCliente";
            Text = "AgregarCliente";
            ((System.ComponentModel.ISupportInitialize)PictureBox1).EndInit();
            Panel1.ResumeLayout(false);
            Panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)DataGridView1).EndInit();
            ((System.ComponentModel.ISupportInitialize)PictureBox2).EndInit();
            Load += new EventHandler(AgregarCliente_Load);
            ResumeLayout(false);
            PerformLayout();
        }

        internal PictureBox PictureBox1;
        internal Button Button2;
        internal Button Button1;
        internal Panel Panel1;
        internal Label Label1;
        internal DataGridView DataGridView1;
        internal Label Label2;
        internal Label Label3;
        internal Label Label4;
        internal Label Label5;
        internal Label Label6;
        internal Label Label7;
        internal ComboBox CbPais;
        internal ComboBox CbEstado;
        internal ComboBox CbCiudad;
        internal ComboBox CbRegion;
        internal ComboBox CbSegmento;
        internal TextBox TxtFiltro;
        internal TextBox TxtIdcrea;
        internal PictureBox PictureBox2;
    }
}