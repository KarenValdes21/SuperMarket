﻿using System;
using System.ComponentModel;
using System.Diagnostics;

namespace SuperMarketEditando.My
{
    internal static partial class MyProject
    {
        internal partial class MyForms
        {

            [EditorBrowsable(EditorBrowsableState.Never)]
            public AgregarCliente m_AgregarCliente;

            public AgregarCliente AgregarCliente
            {
                [DebuggerHidden]
                get
                {
                    m_AgregarCliente = Create__Instance__(m_AgregarCliente);
                    return m_AgregarCliente;
                }
                [DebuggerHidden]
                set
                {
                    if (ReferenceEquals(value, m_AgregarCliente))
                        return;
                    if (value is not null)
                        throw new ArgumentException("Property can only be set to Nothing");
                    Dispose__Instance__(ref m_AgregarCliente);
                }
            }


            [EditorBrowsable(EditorBrowsableState.Never)]
            public Form1 m_Form1;

            public Form1 Form1
            {
                [DebuggerHidden]
                get
                {
                    m_Form1 = Create__Instance__(m_Form1);
                    return m_Form1;
                }
                [DebuggerHidden]
                set
                {
                    if (ReferenceEquals(value, m_Form1))
                        return;
                    if (value is not null)
                        throw new ArgumentException("Property can only be set to Nothing");
                    Dispose__Instance__(ref m_Form1);
                }
            }


            [EditorBrowsable(EditorBrowsableState.Never)]
            public Productos m_Productos;

            public Productos Productos
            {
                [DebuggerHidden]
                get
                {
                    m_Productos = Create__Instance__(m_Productos);
                    return m_Productos;
                }
                [DebuggerHidden]
                set
                {
                    if (ReferenceEquals(value, m_Productos))
                        return;
                    if (value is not null)
                        throw new ArgumentException("Property can only be set to Nothing");
                    Dispose__Instance__(ref m_Productos);
                }
            }

        }


    }
}