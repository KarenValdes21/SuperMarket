﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;

namespace SuperMarketEditando
{

    public class Connection
    {
        private static SqlConnection cnx = new SqlConnection();
        public SqlCommand cmd;
        public SqlDataReader sqlread;
        public string Query;
        private static void Connect()
        {
            try
            {
                cnx.ConnectionString = "Data Source=LAPTOP-RRR3K3KV; Initial Catalog=SuperMarketPrueba2 ;Integrated Security=True";
                cnx.Open();
            }
            catch (Exception ex)
            {
                Interaction.MsgBox("Error al conectar a la base de datos: " + ex.Message);
            }
        }
        private static void Disconect()
        {
            try
            {
                if (cnx.State == ConnectionState.Open)
                {
                    cnx.Close();
                }
            }
            catch (Exception ex)
            {
                Interaction.MsgBox("Error al desconectar de la base de datos: " + ex.Message);
            }
        }
        public static DataTable SelectQuery(string query, Dictionary<string, object> parameters = null)
        {
            var dt = new DataTable();
            try
            {
                Connect();
                var cmd = new SqlCommand(query, cnx);
                var da = new SqlDataAdapter(cmd);
                da.Fill(dt);
            }
            catch (Exception ex)
            {
                Interaction.MsgBox("Error al ejecutar la consulta: " + ex.Message);
            }
            finally
            {
                Disconect();
            }
            return dt;
        }

        public static void LlenarCB(string query, ComboBox Cb)
        {
            SqlDataReader sqlread;
            Connect();
            var cmd = new SqlCommand(query, cnx);
            cmd.ExecuteNonQuery();
            sqlread = cmd.ExecuteReader();
            while (sqlread.Read())
                Cb.Items.Add(new ObtenerId(Conversions.ToString(sqlread["Nombre"]), Conversions.ToString(sqlread["id"]))).ToString();
            Disconect();
            sqlread.Close();
        }


        public static void EliminarProducto(string ProductID)
        {
            try
            {
                Connect();
                var cmd = new SqlCommand("SP_EliminarProducto", cnx);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@ProductoID", SqlDbType.VarChar).Value = ProductID.ToString();

                cmd.ExecuteNonQuery();

                Interaction.MsgBox("Registro eliminado con éxito");
            }
            catch (Exception ex)
            {
                Interaction.MsgBox("Error al eliminar el registro " + ex.Message);
            }
            finally
            {
                Disconect();
            }
        }

        public static void AgregarProducto(string ProductID, string NombreProducto, int UsuarioCrea)
        {
            try
            {
                Connect();
                var cmd = new SqlCommand("SP_AgregarProducto", cnx);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ProductoID", SqlDbType.VarChar).Value = ProductID.ToString();
                cmd.Parameters.AddWithValue("@NombreProducto", SqlDbType.VarChar).Value = NombreProducto.ToString();
                cmd.Parameters.AddWithValue("@IdUsuarioCrea", UsuarioCrea);


                cmd.ExecuteNonQuery();

                Interaction.MsgBox("Producto insertado con éxito");
            }
            catch (Exception ex)
            {
                Interaction.MsgBox("Error al insertar el Producto " + ex.Message);
            }
            finally
            {
                Disconect();
            }
        }
        public static void EditarProducto(string ProductID, string NombreProducto, int UsuarioCrea, DateTime FechaModifica)
        {
            try
            {
                Connect();
                var cmd = new SqlCommand("SP_EditarProducto", cnx);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ProductoID", SqlDbType.VarChar).Value = ProductID.ToString();
                cmd.Parameters.AddWithValue("@NuevoNombreProducto", SqlDbType.VarChar).Value = NombreProducto.ToString();
                cmd.Parameters.AddWithValue("@NuevoIdUsuarioModifica", UsuarioCrea);
                cmd.Parameters.AddWithValue("@fechaModifica", FechaModifica);
                cmd.ExecuteNonQuery();


                Interaction.MsgBox("Producto editado con éxito");
            }
            catch (Exception ex)
            {
                Interaction.MsgBox("Error al editar el registro " + ex.Message);
            }
            finally
            {
                Disconect();
            }
        }
        public static void AgregarCliente(string ClienteID, int UsuarioCrea)
        {
            try
            {
                Connect();
                var cmd = new SqlCommand("SPAgregarCliente", cnx);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ClienteID", SqlDbType.VarChar).Value = ClienteID.ToString();

                cmd.Parameters.AddWithValue("@IdUsuarioCrea", UsuarioCrea);


                cmd.ExecuteNonQuery();

                Interaction.MsgBox("Producto insertado con éxito");
            }
            catch (Exception ex)
            {
                Interaction.MsgBox("Error al insertar el Producto " + ex.Message);
            }
            finally
            {
                Disconect();
            }
        }

    }
}