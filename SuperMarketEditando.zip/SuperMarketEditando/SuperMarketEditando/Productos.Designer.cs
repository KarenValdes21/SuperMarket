﻿using System;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;

namespace SuperMarketEditando
{
    [Microsoft.VisualBasic.CompilerServices.DesignerGenerated()]
    public partial class Productos : Form
    {

        // Form reemplaza a Dispose para limpiar la lista de componentes.
        [DebuggerNonUserCode()]
        protected override void Dispose(bool disposing)
        {
            try
            {
                if (disposing && components is not null)
                {
                    components.Dispose();
                }
            }
            finally
            {
                base.Dispose(disposing);
            }
        }

        // Requerido por el Diseñador de Windows Forms
        private System.ComponentModel.IContainer components;

        // NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
        // Se puede modificar usando el Diseñador de Windows Forms.  
        // No lo modifique con el editor de código.
        [DebuggerStepThrough()]
        private void InitializeComponent()
        {
            var resources = new System.ComponentModel.ComponentResourceManager(typeof(Productos));
            DataGridView1 = new DataGridView();
            DataGridView1.CellContentClick += new DataGridViewCellEventHandler(DataGridView1_CellContentClick);
            Panel1 = new Panel();
            PictureBox3 = new PictureBox();
            PictureBox3.Click += new EventHandler(PictureBox3_Click);
            PictureBox2 = new PictureBox();
            PictureBox2.Click += new EventHandler(PictureBox2_Click);
            ComboBox2 = new ComboBox();
            ComboBox2.SelectedIndexChanged += new EventHandler(ComboBox2_SelectedIndexChanged);
            Label4 = new Label();
            Panel2 = new Panel();
            PictureBox1 = new PictureBox();
            PictureBox1.Click += new EventHandler(PictureBox1_Click_1);
            TxtDate = new DateTimePicker();
            TxtUser = new TextBox();
            BtnEliminarProd = new PictureBox();
            BtnEliminarProd.Click += new EventHandler(PictureBox1_Click);
            BtnEditarProducto = new Button();
            BtnEditarProducto.Click += new EventHandler(BtnEditarProducto_Click);
            BtnAgregarProd = new Button();
            BtnAgregarProd.Click += new EventHandler(Button1_Click);
            Label3 = new Label();
            Label2 = new Label();
            Label1 = new Label();
            Label1.Click += new EventHandler(Label1_Click);
            TxtNombreProducto = new TextBox();
            TxtProductID = new TextBox();
            ((System.ComponentModel.ISupportInitialize)DataGridView1).BeginInit();
            Panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)PictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)PictureBox2).BeginInit();
            Panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)PictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)BtnEliminarProd).BeginInit();
            SuspendLayout();
            // 
            // DataGridView1
            // 
            DataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            DataGridView1.Location = new Point(5, 71);
            DataGridView1.Name = "DataGridView1";
            DataGridView1.Size = new Size(474, 372);
            DataGridView1.TabIndex = 0;
            // 
            // Panel1
            // 
            Panel1.Controls.Add(PictureBox3);
            Panel1.Controls.Add(PictureBox2);
            Panel1.Controls.Add(ComboBox2);
            Panel1.Controls.Add(Label4);
            Panel1.Location = new Point(-5, 1);
            Panel1.Name = "Panel1";
            Panel1.Size = new Size(794, 64);
            Panel1.TabIndex = 1;
            // 
            // PictureBox3
            // 
            PictureBox3.Image = (Image)resources.GetObject("PictureBox3.Image");
            PictureBox3.Location = new Point(720, 17);
            PictureBox3.Name = "PictureBox3";
            PictureBox3.Size = new Size(30, 33);
            PictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            PictureBox3.TabIndex = 17;
            PictureBox3.TabStop = false;
            // 
            // PictureBox2
            // 
            PictureBox2.Image = (Image)resources.GetObject("PictureBox2.Image");
            PictureBox2.Location = new Point(471, 17);
            PictureBox2.Name = "PictureBox2";
            PictureBox2.Size = new Size(31, 28);
            PictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            PictureBox2.TabIndex = 16;
            PictureBox2.TabStop = false;
            // 
            // ComboBox2
            // 
            ComboBox2.FormattingEnabled = true;
            ComboBox2.Location = new Point(232, 21);
            ComboBox2.Name = "ComboBox2";
            ComboBox2.Size = new Size(223, 23);
            ComboBox2.TabIndex = 15;
            // 
            // Label4
            // 
            Label4.AutoSize = true;
            Label4.Location = new Point(43, 24);
            Label4.Name = "Label4";
            Label4.Size = new Size(61, 15);
            Label4.TabIndex = 14;
            Label4.Text = "Productos";
            // 
            // Panel2
            // 
            Panel2.Controls.Add(PictureBox1);
            Panel2.Controls.Add(TxtDate);
            Panel2.Controls.Add(TxtUser);
            Panel2.Controls.Add(BtnEliminarProd);
            Panel2.Controls.Add(BtnEditarProducto);
            Panel2.Controls.Add(BtnAgregarProd);
            Panel2.Controls.Add(Label3);
            Panel2.Controls.Add(Label2);
            Panel2.Controls.Add(Label1);
            Panel2.Controls.Add(TxtNombreProducto);
            Panel2.Controls.Add(TxtProductID);
            Panel2.Location = new Point(484, 71);
            Panel2.Name = "Panel2";
            Panel2.Size = new Size(301, 373);
            Panel2.TabIndex = 2;
            // 
            // PictureBox1
            // 
            PictureBox1.Image = (Image)resources.GetObject("PictureBox1.Image");
            PictureBox1.Location = new Point(175, 304);
            PictureBox1.Name = "PictureBox1";
            PictureBox1.Size = new Size(40, 40);
            PictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            PictureBox1.TabIndex = 16;
            PictureBox1.TabStop = false;
            // 
            // TxtDate
            // 
            TxtDate.Format = DateTimePickerFormat.Short;
            TxtDate.Location = new Point(92, 233);
            TxtDate.Name = "TxtDate";
            TxtDate.Size = new Size(140, 23);
            TxtDate.TabIndex = 15;
            // 
            // TxtUser
            // 
            TxtUser.Location = new Point(63, 204);
            TxtUser.Name = "TxtUser";
            TxtUser.Size = new Size(169, 23);
            TxtUser.TabIndex = 14;
            // 
            // BtnEliminarProd
            // 
            BtnEliminarProd.Image = (Image)resources.GetObject("BtnEliminarProd.Image");
            BtnEliminarProd.Location = new Point(92, 304);
            BtnEliminarProd.Name = "BtnEliminarProd";
            BtnEliminarProd.Size = new Size(42, 40);
            BtnEliminarProd.SizeMode = PictureBoxSizeMode.StretchImage;
            BtnEliminarProd.TabIndex = 13;
            BtnEliminarProd.TabStop = false;
            // 
            // BtnEditarProducto
            // 
            BtnEditarProducto.Location = new Point(175, 264);
            BtnEditarProducto.Name = "BtnEditarProducto";
            BtnEditarProducto.Size = new Size(75, 23);
            BtnEditarProducto.TabIndex = 12;
            BtnEditarProducto.Text = "Modificar";
            BtnEditarProducto.UseVisualStyleBackColor = true;
            // 
            // BtnAgregarProd
            // 
            BtnAgregarProd.Location = new Point(40, 264);
            BtnAgregarProd.Name = "BtnAgregarProd";
            BtnAgregarProd.Size = new Size(75, 23);
            BtnAgregarProd.TabIndex = 11;
            BtnAgregarProd.Text = "Agregar";
            BtnAgregarProd.UseVisualStyleBackColor = true;
            // 
            // Label3
            // 
            Label3.AutoSize = true;
            Label3.Location = new Point(119, 186);
            Label3.Name = "Label3";
            Label3.Size = new Size(47, 15);
            Label3.TabIndex = 5;
            Label3.Text = "Usuario";
            // 
            // Label2
            // 
            Label2.AutoSize = true;
            Label2.Location = new Point(110, 54);
            Label2.Name = "Label2";
            Label2.Size = new Size(70, 15);
            Label2.TabIndex = 4;
            Label2.Text = "Producto ID";
            // 
            // Label1
            // 
            Label1.AutoSize = true;
            Label1.Location = new Point(82, 116);
            Label1.Name = "Label1";
            Label1.Size = new Size(122, 15);
            Label1.TabIndex = 3;
            Label1.Text = "Nombre del Producto";
            // 
            // TxtNombreProducto
            // 
            TxtNombreProducto.Location = new Point(63, 143);
            TxtNombreProducto.Name = "TxtNombreProducto";
            TxtNombreProducto.Size = new Size(169, 23);
            TxtNombreProducto.TabIndex = 1;
            // 
            // TxtProductID
            // 
            TxtProductID.Location = new Point(63, 81);
            TxtProductID.Name = "TxtProductID";
            TxtProductID.Size = new Size(169, 23);
            TxtProductID.TabIndex = 0;
            // 
            // Productos
            // 
            AutoScaleDimensions = new SizeF(7f, 15f);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(788, 452);
            Controls.Add(Panel2);
            Controls.Add(Panel1);
            Controls.Add(DataGridView1);
            Name = "Productos";
            Text = "Productos";
            ((System.ComponentModel.ISupportInitialize)DataGridView1).EndInit();
            Panel1.ResumeLayout(false);
            Panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)PictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)PictureBox2).EndInit();
            Panel2.ResumeLayout(false);
            Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)PictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)BtnEliminarProd).EndInit();
            Load += new EventHandler(Productos_Load);
            ResumeLayout(false);
        }

        internal DataGridView DataGridView1;
        internal Panel Panel1;
        internal Panel Panel2;
        internal TextBox TxtNombreProducto;
        internal TextBox TxtProductID;
        internal Label Label1;
        internal Label Label3;
        internal Label Label2;
        internal Label Label4;
        internal PictureBox BtnEliminarProd;
        internal Button BtnEditarProducto;
        internal Button BtnAgregarProd;
        internal PictureBox PictureBox2;
        internal ComboBox ComboBox2;
        internal PictureBox PictureBox3;
        internal TextBox TxtUser;
        internal DateTimePicker TxtDate;
        internal PictureBox PictureBox1;
    }
}