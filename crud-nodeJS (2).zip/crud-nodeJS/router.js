const express = require('express');
const router = express();

const connection = require('./database/database');

/**
 * HOME
 */
router.get('/', (req, res)=>{
    res.render('index', {var1: 'Hola'});
})

/**
 * CLIENTES
 */
router.get('/clientes', (req, res)=>{
    connection.query('SELECT id, ClienteID, fechaCrea FROM cliente', (error, results)=>{
        if(error){
            console.log(error);
        }else{
            res.render('clientes', {results: results});
        }
    })
})

// Eliminar
router.get('/clientes/:id', (req, res) => {
    const id_data = req.params.id;
    const sql = 'CALL SP_EliminarCliente(?)';
    connection.query(sql, [id_data], (error, results) => {
        if (error) {
            console.error('Error al ejecutar el stored procedure: ' + error.message);
            return;
        }
        console.log('El registro ha sido eliminado exitosamente');
        res.redirect('/clientes');
    });
});

router.get('/clientes/:id/data', (req, res) => {
    const id_data = req.params.id;
    connection.query('SELECT id, ClienteID, idUsuarioModifica FROM cliente WHERE estatus = 1 AND id = ?', [id_data], (error, results)=>{
        if(error){
            console.log(error);
        }else{
            res.render('editar_cliente', { row: results }); //
        }
    })
})

router.post('/cliente_add', (req, res) => {
    const ClienteID = req.body.ClienteID;
    const IdUsuarioCrea = req.body.IdUsuarioCrea;
    const sql = 'CALL SP_AgregarCliente(?, ?)';
    connection.query(sql, [ClienteID, IdUsuarioCrea], (error, results) => {
      if (error) {
        console.error('Error al ejecutar el stored procedure: ' + error.message);
        return;
      }
      console.log('Datos insertados correctamente');
    
      res.redirect('/clientes');
    });
  });

  router.post('/cliente_update', (req, res) => {
    const id = req.body.id;
    const ClienteID = req.body.clienteID;
    const IdUsuarioCrea = req.body.modifica;
    const sql = 'CALL SP_EditarCliente(?, ?, ?)';
    connection.query(sql, [id, ClienteID, IdUsuarioCrea], (error, results) => {
      if (error) {
        console.error('Error al ejecutar el stored procedure: ' + error.message);
        return;
      }
      console.log('Datos Modificados correctamente');
    
      res.redirect('/clientes');
    });
  });

module.exports = router;




/**
 * PEDIDOS
 */
router.get('/pedidos', (req, res)=>{
    connection.query('SELECT id, PedidoID, Precio, Cantidad, Descuento, Ganancia, OrdenFecha,EnvioFecha, ModoEnvio, idUsuarioModifica FROM pedido WHERE estatus = 1', (error, results)=>{
        if(error){
            console.log(error);
        }else{
            res.render('pedidos', {results: results});
        }
    })
})

// Eliminar
router.get('/pedidos/:id', (req, res) => {
    const id_data = req.params.id;
    const sql = 'CALL SP_EliminarPedido(?)';
    connection.query(sql, [id_data], (error, results) => {
        if (error) {
            console.error('Error al ejecutar el stored procedure: ' + error.message);
            return;
        }
        console.log('El registro ha sido eliminado exitosamente');
        res.redirect('/pedidos');
    });
});

router.get('/pedidos/:id/data', (req, res) => {
    const id_data = req.params.id;
    connection.query('SELECT PedidoID, Precio, Cantidad, Descuento, Ganancia, OrdenFecha, EnvioFecha, ModoEnvio, idUsuarioModifica FROM pedido WHERE estatus = 1 AND id = ?', [id_data], (error, results)=>{
        if(error){
            console.log(error);
        }else{
            res.render('editar_pedido', { row: results }); //
        }
    })
})

router.post('/pedidos_add', (req, res) => {
    const idPedido = req.body.idPedido;
    const precio = req.body.precio;
    const cantidad = req.body.cantidad;

    const descuento = req.body.descuento;
    const ganancia = req.body.ganancia;
    const fechaPedido = req.body.fechaPedido;
    const fechaEnvio = req.body.fechaEnvio;
    const modoEnvio = req.body.modoEnvio;
    // Llamar al stored procedure para insertar los datos en la base de datos
    const sql = 'CALL SP_AgregarPedido(?, ?, ?, ?, ?, ?, ?, ?)';
    connection.query(sql, [idPedido, precio, cantidad, descuento, ganancia, fechaPedido, fechaEnvio, modoEnvio], (error, results) => {
      if (error) {
        console.error('Error al ejecutar el stored procedure: ' + error.message);
        return;
      }
      console.log('Datos insertados correctamente');
    
      res.redirect('/pedidos');
    });
  });

  router.post('/pedidos_update', (req, res) => {
    const idPedido = req.body.idPedido;
    const precio = req.body.precio;
    const cantidad = req.body.cantidad;
    const descuento = req.body.descuento;
    const ganancia = req.body.ganancia;
    const fechaEnvio = req.body.fechaEnvio;
    const fechaPedido = req.body.fechaPedido;
    const modoEnvio = req.body.modoEnvio;
    const idUsuarioModifica = req.body.idUsuarioModifica;
    const sql = 'CALL SP_EditarPedido(?, ?, ?, ?, ?, ?, ?, ?, ?)';

    connection.query(sql, [idPedido, precio, cantidad, descuento, ganancia, fechaEnvio, fechaPedido, modoEnvio, idUsuarioModifica], (error, results) => {
      if (error) {
        console.error('Error al ejecutar el stored procedure: ' + error.message);
        return;
      }
      console.log('Datos Modificados correctamente');
    
      res.redirect('/pedidos');
    });
  });





/**
 * PRODUCTOS
 */
router.get('/productos', (req, res)=>{
    connection.query('SELECT ProductoID, NombreProducto, idSubcategoria, fechaCrea, idUsuarioModifica FROM producto WHERE estatus = 1', (error, results)=>{
        if(error){
            console.log(error);
        }else{
            res.render('productos', {results: results});
        }
    })
})
// Eliminar
router.get('/productos/:id', (req, res) => {
    const id_data = req.params.id;
    const sql = 'CALL SP_EliminarProducto(?)';
    connection.query(sql, [id_data], (error, results) => {
        if (error) {
            console.error('Error al ejecutar el stored procedure: ' + error.message);
            return;
        }
        console.log('El registro ha sido eliminado exitosamente');
        res.redirect('/productos');
    });
});

router.get('/productos/:id/data', (req, res) => {
    const id_data = req.params.id;
    connection.query('SELECT ProductoID, NombreProducto, idUsuarioModifica FROM producto WHERE estatus = 1 AND ProductoID = ?', [id_data], (error, results)=>{
        if(error){
            console.log(error);
        }else{
            res.render('editar_producto', { row: results }); //
        }
    })
})

router.post('/productos_add', (req, res) => {
    const ProductoID = req.body.ProductoID;
    const NombreProducto = req.body.NombreProducto;
    const IdUsuarioCrea = req.body.IdUsuarioCrea;
    const sql = 'CALL SP_AgregarProducto(?, ?, ?)';
    connection.query(sql, [ProductoID, NombreProducto, IdUsuarioCrea], (error, results) => {
      if (error) {
        console.error('Error al ejecutar el stored procedure: ' + error.message);
        return;
      }
      console.log('Datos insertados correctamente');
    
      res.redirect('/productos');
    });
  });


  router.post('/productos_update', (req, res) => {
    const ProductoID = req.body.id;
    const NombreProducto = req.body.nombre;
    const IdUsuarioCrea = req.body.modifica;
    const sql = 'CALL SP_EditarProducto(?, ?, ?)';
    connection.query(sql, [ProductoID, NombreProducto, IdUsuarioCrea], (error, results) => {
      if (error) {
        console.error('Error al ejecutar el stored procedure: ' + error.message);
        return;
      }
      console.log('Datos Modificados correctamente');
    
      res.redirect('/productos');
    });
  });


module.exports = router;